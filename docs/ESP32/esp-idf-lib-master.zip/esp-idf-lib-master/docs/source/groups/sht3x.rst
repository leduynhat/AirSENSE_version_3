sht3x - Driver for Sensirion SHT3x digital temperature and humidity sensor
==========================================================================

.. doxygengroup:: sht3x

