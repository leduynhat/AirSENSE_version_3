tca95x5 - Driver for TCA9535/TCA9555 remote 16-bit I/O expanders for I2C-bus
============================================================================

.. doxygengroup:: tca95x5

