tda74xx - Driver for TDA7439/TDA7439DS/TDA7440D audioprocessors
===============================================================

.. doxygengroup:: tda74xx

