Copy certificate files for AWS IoT SDK example here

See README.md in main example directory for details.
