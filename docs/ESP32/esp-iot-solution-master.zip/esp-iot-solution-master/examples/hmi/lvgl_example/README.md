# LittlevGL Widget

[[中文]](lvgl_example_cn.md) / [[EN]](lvgl_example_en.md)