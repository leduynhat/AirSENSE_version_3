# LittlevGL Thermostat Panel

[[中文]](lvgl_thermostat_cn.md) / [[EN]](lvgl_thermostat_en.md)