[[EN]](readme_en.md) 

## Deep-sleep 低功耗方案设计

* [RTC IO 唤醒 Deep Sleep 时功耗测试](deep-sleep_current_test_cn.md)
* [ESP32 低功耗方案设计](esp32_lowpower_solution_cn.md)
* [ESP32 的 ULP 协处理器简介和汇编编译环境设置](esp32_ulp_co-processor_and_assembly_environment_setup_cn.md)

[[首页]](../readme_en.md)