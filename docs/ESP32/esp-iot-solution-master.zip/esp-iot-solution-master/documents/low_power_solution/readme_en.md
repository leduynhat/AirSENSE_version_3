[[中文]](readme_cn.md) 

## Deep-sleep low power solutions overview

* [Current Consumption Test for ESP32 in Deep Sleep](deep-sleep_current_test_en.md)
* [ESP32 Low-Power Management Overview](esp32_lowpower_solution_en.md)
* [ESP32 ULP Co-processor and Assembly Environment Setup](esp32_ulp_co-processor_and_assembly_environment_setup_en.md)

[[Documentation Home]](../readme_en.md)