[[中文]](readme_cn.md)

* [Touch Sensor Application Note](touch_sensor_design_en.md)

[[Documentation Home]](../readme_en.md)
