[[EN]](readme_en.md) 

## Light-sleep 低功耗方案概述

* __ESP32 DFS 功能测试指南__ (中文文档即将发布)
* __ESP32 Light-sleep 特性__ (中文文档即将发布)
* [ESP32 Light-sleep 测试指南](./light_sleep_test_manual_cn.md)

[[首页]](../readme_en.md)