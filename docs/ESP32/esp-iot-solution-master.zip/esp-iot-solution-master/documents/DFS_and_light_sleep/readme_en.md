[[中文]](readme_cn.md) 

## Light-sleep low power solutions overview

* [ESP32 DFS test manual](./DFS_test_manual_en.md)
* [ESP32 Light-sleep features](./light_sleep_performance_en.md)
* __ESP32 Light-sleep test manual__ (English version is about to release)

[[Documentation Home]](../readme_en.md)