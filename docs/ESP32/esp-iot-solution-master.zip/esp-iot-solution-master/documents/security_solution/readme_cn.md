[[EN]](readme_en.md)

## ESP32 芯片加密方案设计

* [ESP32 加/解密方案](esp32_secure_and_encrypt_cn.md)
* __下载工具介绍__ (中文文档即将发布)

[[首页]](../readme_cn.md)
