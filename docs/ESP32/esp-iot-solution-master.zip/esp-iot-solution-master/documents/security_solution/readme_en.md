[[中文]](readme_cn.md)

## Security and Factory Flow

* __ESP32 secure and encrypt__ (English version is about to release)
* [Download Tool GUI instruction](download_tool_en.md)

[[Documentation Home]](../readme_en.md)
