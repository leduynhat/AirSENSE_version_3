# Component: HTS221
* Driver and definition of HTS221

