# Component: VEML6040

* This component will show you how to use I2C module read external i2c sensor data, here we use veml6040 UV light sensor(color sensor)
