# Component: BH1750

* This component defines an I2C bus object.
* Other sensor object can contain this bus as a private member.
