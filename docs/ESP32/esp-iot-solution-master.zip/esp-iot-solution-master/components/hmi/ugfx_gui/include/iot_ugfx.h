/*
 * This file is subject to the terms of the GFX License. If a copy of
 * the license was not distributed with this file, you can obtain one at:
 *
 *              http://ugfx.org/license.html
 */

#ifndef _GUI_UGFX_H
#define _GUI_UGFX_H

#include "gos_freertos_priv.h"
#include "gfxconf.h"

#include "gfx.h"
#include "gfxconf.h"

#endif /* _GUI_UGFX_H */

