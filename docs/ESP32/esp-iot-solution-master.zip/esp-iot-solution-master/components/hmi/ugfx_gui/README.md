[[中文]](../../../documents/hmi_solution/ugfx/ugfx_guide_cn.md)/[[EN]]((../../../documents/hmi_solution/ugfx/ugfx_guide_en.md))
