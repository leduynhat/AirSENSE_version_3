[[中文]](../../../documents/hmi_solution/littlevgl/littlevgl_guide_cn.md)/[[EN]]((../../../documents/hmi_solution/littlevgl/littlevgl_guide_en.md))
