# Component: rmt_nec

* This component provide api to send/recv data from infrared transmission.

* Call ir_nec_send() to send infrared data through nec protocol.
* Call ir_nec_recv() to receive infrared data through nec protocol. 

### NOTE:
> Call ir_nec_init() at first if you want to use this component.

# Todo: 

* Check what other function can be added.
