#ifndef _FONT_H_
#define _FONT_H_

#define NR_CHRS_F7S   96
#define CHR_HGT_F7S   48
#define DATA_SIZE_F7S  8
#define FIRSTCHR_F7S  32

extern const unsigned char widtbl_f7s[96];
extern const unsigned char *chrtbl_f7s[96];

#endif