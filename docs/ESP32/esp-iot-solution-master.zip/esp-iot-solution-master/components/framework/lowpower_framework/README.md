# Component: lowpower_app_framework

* This component provides a framework of lowpower application. This framework is based on deepsleep function, and designed a workflow of typical lowpower application.
* When use this framework, user just need to register the relevant callback functions, and start the framework.

* The workflow of this framework is as shown in the following figure  
![](../../../documents/_static/lowpower_evb/workflow_of_framwork.png)  
